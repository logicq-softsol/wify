
import { Injectable, Inject} from '@angular/core';
import { Http,Headers,RequestOptions,Response,RequestMethod,Request} from '@angular/http';
import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Observable';

@Injectable()
export class AppService {
  constructor(private http :Http) { 
    
  }


 callInitData(){
    let postheaders = new Headers({'Content-Type': 'application/json','Access-Control-Allow-Origin':'*'});
    let options = new RequestOptions({ headers: postheaders });
    return this.http.get("http://10.10.150.218:8090/api/executedInitReport",options).map(res=>res.json());
  }
  
  callInitDataHourly(){
    let postheaders = new Headers({'Content-Type': 'application/json','Access-Control-Allow-Origin':'*'});
    let options = new RequestOptions({ headers: postheaders });
    return this.http.get("http://10.10.150.218:8090/api/executedInitReport/HOURLY",options).map(res=>res.json());
  }

  callInitDataDaily(){
    let postheaders = new Headers({'Content-Type': 'application/json','Access-Control-Allow-Origin':'*'});
    let options = new RequestOptions({ headers: postheaders });
    return this.http.get("http://10.10.150.218:8090/api/executedInitReport/DAILY",options).map(res=>res.json());
  }

  callInitDataMonthly(){
    let postheaders = new Headers({'Content-Type': 'application/json','Access-Control-Allow-Origin':'*'});
    let options = new RequestOptions({ headers: postheaders });
    return this.http.get("http://10.10.150.218:8090/api/executedInitReport/MONTHLY",options).map(res=>res.json());
  }

  callInitDataCurrentDay(){
    let postheaders = new Headers({'Content-Type': 'application/json','Access-Control-Allow-Origin':'*'});
    let options = new RequestOptions({ headers: postheaders });
    return this.http.get("http://10.10.150.218:8090/api/executedInitReport/CURRENT_DAY",options).map(res=>res.json());
  }

  callInitDataCurrentHour(){
    let postheaders = new Headers({'Content-Type': 'application/json','Access-Control-Allow-Origin':'*'});
    let options = new RequestOptions({ headers: postheaders });
    return this.http.get("http://10.10.150.218:8090/api/executedInitReport/CURRENT_HOUR",options).map(res=>res.json());
  }
}