import { Component } from '@angular/core';
import Stomp from 'stompjs';
import SockJS from 'sockjs-client';
import { OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { ElementRef, AfterViewInit, OnDestroy, ViewChild } from '@angular/core';
import 'highcharts/adapters/standalone-framework.src';
import { chart } from 'highcharts';
import { AppService } from './app.service';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css'],
    providers: []
})


export class AppComponent implements OnInit, OnDestroy, AfterViewInit {

    @ViewChild('chart') public chartEl: ElementRef;



    private _chart: any;
    public initData: Observable<any>;


    public ngOnDestroy() {
        this._chart.destroy();

    }
    //private serverUrl = 'http://127.0.0.1:8090/socket'
    private serverUrl = 'http://10.10.150.218:8090/socket'
    private stompClient;

    public basescanner: number;
    public memoryscanner: number;
    public virusprotection: number;
    public mailprotection: number;
    public propertysheetscanner: number;
    public quarantinescanner: number;
    public otherscanner: number;

    public basescannerCurrent: number;
    public memoryscannerCurrent: number;
    public virusprotectionCurrent: number;
    public mailprotectionCurrent: number;
    public propertysheetscannerCurrent: number;
    public quarantinescannerCurrent: number;
    public otherscannerCurrent: number;


    public basescannerperhour: number;
    public memoryscannerperhour: number;
    public virusprotectionperhour: number;
    public mailprotectionperhour: number;
    public propertysheetscannerperhour: number;
    public quarantinescannerperhour: number;
    public otherscannerperhour: number;

    public basescannerday: number;
    public memoryscannerday: number;
    public virusprotectionday: number;
    public mailprotectionday: number;
    public propertysheetscannerday: number;
    public quarantinescannerday: number;
    public otherscannerday: number;

    public basescannermonth: number;
    public memoryscannermonth: number;
    public virusprotectionmonth: number;
    public mailprotectionmonth: number;
    public propertysheetscannermonth: number;
    public quarantinescannermonth: number;
    public otherscannermonth: number;

    public baseAlertColor: string;
    public memoryAlertColor: string;
    public virusAlertColor: string;
    public mailAlertColor: string;
    public propertyAlertColor: string;
    public quaranAlertColor: string;
    public alertThreshold = 200;

    public virusCurrHR: number;
    public baseCurrHR: number;
    public memoryCurrHR: number;
    public mailCurrHR: number;
    public propertyCurrHR: number;
    public quarantinesCurrHR: number;


    


    public alertData = [{ timestamp: '', name: "VIRUS_PROTECTION",displayName:"VIRUS", count: 0 }, { timestamp: '', name: "BASE_SCANNER",displayName:"BASE", count: 0 }, { timestamp: '', name: "MEMORY_SCANNER",displayName:"MEMORY", count: 0 }, { timestamp: '', name: "MAIL_PROTECTION",displayName:"MAIL", count: 0 }, { timestamp: '', name: "PROPERTY_SHEET_SCANNER",displayName:"PROPERTY", count: 0 }, { timestamp: '', displayName:"QUARANTINE",name: "QUARANTINE_SCANNER", count: 0 }];



    constructor(private appService: AppService) {
        const me = this;
        let ws = new SockJS(this.serverUrl);

        this.stompClient = Stomp.over(ws);

        let that = this;




        this.stompClient.connect({}, function (frame) {

            that.stompClient.subscribe("/livereport/HOURLY", (hourlyresponse) => {
                if (hourlyresponse.body) {
                    var resultDataHourly = JSON.parse(hourlyresponse.body);
                    if (null != resultDataHourly) {
                        resultDataHourly.results.forEach(datah => {
                            datah.countResult.forEach(counth => {

                                if ("VIRUS_PROTECTION" == counth.name) {
                                    me.virusprotectionperhour = counth.count;
                                }
                                if ("BASE_SCANNER" == counth.name) {
                                    me.basescannerperhour = counth.count;
                                }

                                if ("MEMORY_SCANNER" == counth.name) {
                                    me.memoryscannerperhour = counth.count;
                                }
                                if ("MAIL_PROTECTION" == counth.name) {
                                    me.mailprotectionperhour = counth.count;
                                }
                                if ("PROPERTY_SHEET_SCANNER" == counth.name) {
                                    me.propertysheetscannerperhour = counth.count;
                                }
                                if ("QUARANTINE_SCANNER" == counth.name) {
                                    me.quarantinescannerperhour = counth.count;
                                }
                                if ("OTHER_SCANNER" == counth.name) {
                                    me.otherscannerperhour = counth.count;
                                }
                            })
                        })

                    }
                }
            });


            that.stompClient.subscribe("/livereport", (response) => {
                if (response.body) {
                    var eachSecond = JSON.parse(response.body);
                    if (me._chart && null != eachSecond) {
                        eachSecond.results.forEach(data => {
                            data.countResult.forEach(count => {

                                Object.keys(me.alertData).forEach(key => {
                                    if (me.alertData[key].name === count.name && me.alertData[key].count < count.count) {
                                        me.alertData[key].count = count.count;
                                        me.alertData[key].timestamp = data.time;
                                    }
                                });

                                if ("VIRUS_PROTECTION" == count.name) {
                                    me.virusprotection = count.count;
                                    me.virusprotectionCurrent=me.virusprotectionCurrent+count.count;
                                    me.virusCurrHR=me.virusCurrHR+count.count;
                                    if (count.count > me.alertThreshold)
                                        me.virusAlertColor = "#ec5645";
                                    else
                                        me.virusAlertColor = "#ccc";
                                    me._chart['series'][0].addPoint([data.time, count.count], true, true);
                                }
                                if ("BASE_SCANNER" == count.name) {
                                    me.basescanner = count.count;
                                    me.basescannerCurrent= me.basescannerCurrent+count.count;
                                    me.baseCurrHR= me.baseCurrHR+count.count;
                                    if (count.count > me.alertThreshold)
                                        me.baseAlertColor = "#ec5645";
                                    else
                                        me.baseAlertColor = "#ccc";
                                    me._chart['series'][1].addPoint([data.time, count.count], true, true);
                                }

                                if ("MEMORY_SCANNER" == count.name) {
                                    me.memoryscanner = count.count;
                                    me.memoryscannerCurrent=me.memoryscannerCurrent+ count.count;
                                    me.memoryCurrHR=me.memoryCurrHR+ count.count;
                                    if (count.count > me.alertThreshold)
                                        me.memoryAlertColor = "#ec5645";
                                    else
                                        me.memoryAlertColor = "#ccc";
                                    me._chart['series'][2].addPoint([data.time, count.count], true, true);
                                }
                                if ("MAIL_PROTECTION" == count.name) {
                                    me.mailprotection = count.count;
                                    me.mailprotectionCurrent=me.mailprotectionCurrent+count.count;
                                    me.mailCurrHR=me.mailCurrHR+count.count;
                                    if (count.count > me.alertThreshold)
                                        me.mailAlertColor = "#ec5645";
                                    else
                                        me.mailAlertColor = "#ccc";
                                    me._chart['series'][3].addPoint([data.time, count.count], true, true);
                                }
                                if ("PROPERTY_SHEET_SCANNER" == count.name) {
                                    me.propertysheetscanner = count.count;
                                    me.propertysheetscannerCurrent=me.propertysheetscannerCurrent+count.count;
                                    me.propertyCurrHR=me.propertyCurrHR+count.count;
                                    if (count.count > me.alertThreshold)
                                        me.propertyAlertColor = "#ec5645";
                                    else
                                        me.propertyAlertColor = "#ccc";
                                    me._chart['series'][4].addPoint([data.time, count.count], true, true);
                                }
                                if ("QUARANTINE_SCANNER" == count.name) {
                                    me.quarantinescanner = count.count;
                                    me.quarantinescannerCurrent=me.quarantinescannerCurrent+count.count;
                                    me.quarantinesCurrHR=me.quarantinesCurrHR+count.count;
                                    if (count.count > me.alertThreshold)
                                        me.quaranAlertColor = "#ec5645";
                                    else
                                        me.quaranAlertColor = "#ccc";
                                    me._chart['series'][5].addPoint([data.time, count.count], true, true);
                                }
                            })
                        })


                    }


                }

            });


        });






    }


    public ngAfterViewInit() {

        let dataArry = [{ x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }];

        let opts: Highcharts.Options = {
            chart: {
                type: 'spline',
                animation: false,
                marginRight: 10,
            },
            title: {
                text: '',
                style: {
                    display: 'Live Module Count'
                }
            },
            subtitle: {
                text: '',
                style: {
                    display: 'none'
                }
            },

            xAxis: {

                type: 'datetime',
                tickPixelInterval: 300,
            },
            credits: {
                enabled: false
            },
            legend: {
                enabled: true
            },
            plotOptions: {
                spline: {
                    dataLabels: {
                        enabled: false
                    },
                    marker: {
                        enabled: false
                    },
                    enableMouseTracking: false
                }
            },
            series:
                [{
                    name: 'VIRUS',
                    data: dataArry
                },
                {
                    name: 'BASE',
                    data: dataArry
                },
                {
                    name: 'MEMORY',
                    data: dataArry
                },
                {
                    name: 'MAIL',
                    data: dataArry
                }, {
                    name: 'PROPERTY',
                    data: dataArry
                }, {
                    name: 'QUARANTINE',
                    data: dataArry
                }]
        };


        if (this.chartEl && this.chartEl.nativeElement) {
            opts.chart = {
                type: 'spline',
                renderTo: this.chartEl.nativeElement
            };
            this._chart = chart(this.chartEl.nativeElement, opts);
        }

        this.appService.callInitData().subscribe(resultInit => {
            if (this._chart && null != resultInit) {
                resultInit.results.forEach(datain => {
                    datain.countResult.forEach(countin => {
                        Object.keys(this.alertData).forEach(key => {
                            if (this.alertData[key].name === countin.name && this.alertData[key].count < countin.count) {
                                this.alertData[key].count = countin.count;
                                this.alertData[key].timestamp = datain.time;
                            }
                        });

                        if ("VIRUS_PROTECTION" == countin.name) {
                            this._chart['series'][0].addPoint([datain.time, countin.count], true, true);
                        }
                        if ("BASE_SCANNER" == countin.name) {
                            this._chart['series'][1].addPoint([datain.time, countin.count], true, true);
                        }

                        if ("MEMORY_SCANNER" == countin.name) {
                            this._chart['series'][2].addPoint([datain.time, countin.count], true, true);
                        }
                        if ("MAIL_PROTECTION" == countin.name) {
                            this._chart['series'][3].addPoint([datain.time, countin.count], true, true);
                        }
                        if ("PROPERTY_SHEET_SCANNER" == countin.name) {
                            this._chart['series'][4].addPoint([datain.time, countin.count], true, true);
                        }
                        if ("QUARANTINE_SCANNER" == countin.name) {
                            this._chart['series'][5].addPoint([datain.time, countin.count], true, true);
                        }

                    })
                })
            }
        });

        this.appService.callInitDataHourly().subscribe(resultHour => {
            if (null != resultHour) {
                resultHour.results.forEach(datah => {
                    datah.countResult.forEach(counth => {

                        if ("VIRUS_PROTECTION" == counth.name) {
                            this.virusprotectionperhour = counth.count;
                        }
                        if ("BASE_SCANNER" == counth.name) {
                            this.basescannerperhour = counth.count;
                        }

                        if ("MEMORY_SCANNER" == counth.name) {
                            this.memoryscannerperhour = counth.count;
                        }
                        if ("MAIL_PROTECTION" == counth.name) {
                            this.mailprotectionperhour = counth.count;
                        }
                        if ("PROPERTY_SHEET_SCANNER" == counth.name) {
                            this.propertysheetscannerperhour = counth.count;
                        }
                        if ("QUARANTINE_SCANNER" == counth.name) {
                            this.quarantinescannerperhour = counth.count;
                        }
                    })
                })

            }
        });


        this.appService.callInitDataDaily().subscribe(resultDaily => {
            if (null != resultDaily) {
                resultDaily.results.forEach(datad => {
                    datad.countResult.forEach(countd => {
                       
                        if ("VIRUS_PROTECTION" == countd.name) {
                            this.virusprotectionday = countd.count;
                        }
                        if ("BASE_SCANNER" == countd.name) {
                            this.basescannerday = countd.count;
                        }
                        if ("MEMORY_SCANNER" == countd.name) {
                            this.memoryscannerday = countd.count;
                        }
                        if ("MAIL_PROTECTION" == countd.name) {
                            this.mailprotectionday = countd.count;
                        }
                        if ("PROPERTY_SHEET_SCANNER" == countd.name) {
                            this.propertysheetscannerday = countd.count;
                        }
                        if ("QUARANTINE_SCANNER" == countd.name) {
                            this.quarantinescannerday = countd.count;
                        }
                    })
                })
              
            }
        });


        this.appService.callInitDataCurrentDay().subscribe(resultCurrentDaily => {
            if (null != resultCurrentDaily) {
                resultCurrentDaily.results.forEach(datacd => {
                    datacd.countResult.forEach(countcd => {
                       
                        if ("VIRUS_PROTECTION" == countcd.name) {
                            this.virusprotectionCurrent = countcd.count;
                        }
                        if ("BASE_SCANNER" == countcd.name) {
                            this.basescannerCurrent = countcd.count;
                        }
                        if ("MEMORY_SCANNER" == countcd.name) {
                            this.memoryscannerCurrent = countcd.count;
                        }
                        if ("MAIL_PROTECTION" == countcd.name) {
                            this.mailprotectionCurrent = countcd.count;
                        }
                        if ("PROPERTY_SHEET_SCANNER" == countcd.name) {
                            this.propertysheetscannerCurrent = countcd.count;
                        }
                        if ("QUARANTINE_SCANNER" == countcd.name) {
                            this.quarantinescannerCurrent = countcd.count;
                        }
                    })
                })
              
            }
        });


        this.appService.callInitDataCurrentHour().subscribe(resultCurrHR => {
            if (null != resultCurrHR) {
                resultCurrHR.results.forEach(datach => {
                    datach.countResult.forEach(countch => {
                       
                        if ("VIRUS_PROTECTION" == countch.name) {
                            this.virusCurrHR = countch.count;
                        }
                        if ("BASE_SCANNER" == countch.name) {
                            this.baseCurrHR = countch.count;
                        }
                        if ("MEMORY_SCANNER" == countch.name) {
                            this.memoryCurrHR = countch.count;
                        }
                        if ("MAIL_PROTECTION" == countch.name) {
                            this.mailCurrHR = countch.count;
                        }
                        if ("PROPERTY_SHEET_SCANNER" == countch.name) {
                            this.propertyCurrHR = countch.count;
                        }
                        if ("QUARANTINE_SCANNER" == countch.name) {
                            this.quarantinesCurrHR = countch.count;
                        }
                    })
                })
              
            }
        });

    }

    ngOnInit() {

    }




}