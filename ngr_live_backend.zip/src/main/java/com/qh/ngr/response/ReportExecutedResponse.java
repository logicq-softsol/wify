package com.qh.ngr.response;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.qh.ngr.vo.report.ResultVO;

/**
 * 
 * @author ajay.singh
 *
 */
public class ReportExecutedResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String reportTemplateId;
	private String dashboardId;
	private List<ResultVO> results = new ArrayList<>();
	private Boolean reportExecuted = false;

	private Map<String, Map<String, Object>> liveCounts;

	public String getReportTemplateId() {
		return reportTemplateId;
	}

	public void setReportTemplateId(String reportTemplateId) {
		this.reportTemplateId = reportTemplateId;
	}

	public String getDashboardId() {
		return dashboardId;
	}

	public void setDashboardId(String dashboardId) {
		this.dashboardId = dashboardId;
	}

	public List<ResultVO> getResults() {
		return results;
	}

	public void setResults(List<ResultVO> results) {
		this.results = results;
	}

	public Map<String, Map<String, Object>> getLiveCounts() {
		return liveCounts;
	}

	public void setLiveCounts(Map<String, Map<String, Object>> liveCounts) {
		this.liveCounts = liveCounts;
	}

	public Boolean getReportExecuted() {
		return reportExecuted;
	}

	public void setReportExecuted(Boolean reportExecuted) {
		this.reportExecuted = reportExecuted;
	}

	@Override
	public String toString() {
		return "ReportExecutedResponse [reportTemplateId=" + reportTemplateId + ", dashboardId=" + dashboardId
				+ ", results=" + results + ", reportExecuted=" + reportExecuted + ", liveCounts=" + liveCounts + "]";
	}


}
