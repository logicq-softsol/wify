package com.qh.ngr.model.report;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "REPORT_TEMPLATE")
public class ReportTemplate implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 526372552084544761L;

	@EmbeddedId
	private ReportTemplateKey reportTemplateKey;

	@Lob
	@Column(name = "TEMPLATE_JSON", nullable = false)
	private byte[] templateJson;

	@Column(name = "DISPLAY_NAME", nullable = false)
	private String displayName;

	@Column(name = "TYPE", nullable = false)
	private String reportType;

	@Column(name = "LAST_EXECTION_INTERVAL")
	private String executionInterval;

	
	public ReportTemplateKey getReportTemplateKey() {
		return reportTemplateKey;
	}

	public void setReportTemplateKey(ReportTemplateKey reportTemplateKey) {
		this.reportTemplateKey = reportTemplateKey;
	}

	public byte[] getTemplateJson() {
		return templateJson;
	}

	public void setTemplateJson(byte[] templateJson) {
		this.templateJson = templateJson;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	public String getExecutionInterval() {
		return executionInterval;
	}

	public void setExecutionInterval(String executionInterval) {
		this.executionInterval = executionInterval;
	}

	@Override
	public String toString() {
		return "ReportTemplate [reportTemplateKey=" + reportTemplateKey + ", templateJson="
				+ Arrays.toString(templateJson) + ", displayName=" + displayName + ", reportType=" + reportType
				+ ", executionInterval=" + executionInterval + "]";
	}

}
