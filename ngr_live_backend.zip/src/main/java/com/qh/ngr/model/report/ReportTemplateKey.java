package com.qh.ngr.model.report;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;



@Embeddable
public class ReportTemplateKey implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1092377783748206877L;


	@Column(name = "REPORT_ID", nullable = false)
	private String reportId;

	@Column(name = "DASHBOARD_ID", nullable = false)
	private String dashboardId;

	
	
	public String getReportId() {
		return reportId;
	}

	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	public String getDashboardId() {
		return dashboardId;
	}

	public void setDashboardId(String dashboardId) {
		this.dashboardId = dashboardId;
	}

	@Override
	public String toString() {
		return "ReportTemplateKey [reportId=" + reportId + ", dashboardId=" + dashboardId + "]";
	}

}
