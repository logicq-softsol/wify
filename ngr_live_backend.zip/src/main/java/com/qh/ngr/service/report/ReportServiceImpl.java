package com.qh.ngr.service.report;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qh.ngr.model.report.ReportTemplate;
import com.qh.ngr.model.report.ReportTemplateKey;
import com.qh.ngr.repository.ReportRepository;

@Service
@Transactional
public class ReportServiceImpl implements ReportService {

	@Autowired
	ReportRepository reportRepository;

	@Override
	public ReportTemplate findReportTemplate(String dashboardId, String reportId) {
		ReportTemplateKey templetKey = new ReportTemplateKey();
		templetKey.setDashboardId(dashboardId);
		templetKey.setReportId(reportId);
		return reportRepository.findOne(templetKey);
	}

	@Override
	public List<ReportTemplate> findAllReportTemplates() {
		return reportRepository.findAll();
	}

}
