package com.qh.ngr.service.report;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.qh.ngr.client.druid.DruidRestClient;
import com.qh.ngr.model.report.ReportTemplate;
import com.qh.ngr.response.ReportExecutedResponse;
import com.qh.ngr.utils.DateUtils;
import com.qh.ngr.utils.RandomGenerator;

@Service
@Transactional
public class ReportExecutorServiceImpl implements ReportExecutorService {

	private static final Logger logger = Logger.getLogger(ReportExecutorServiceImpl.class);

	@Autowired
	ReportService reportService;

	@Autowired
	RandomGenerator randomGenerator;

	@Autowired
	DruidRestClient druidRestClient;

	@Autowired
	private SimpMessagingTemplate template;

	@Autowired
	private DateUtils dateUtils;

	private Map<String, ReportTemplate> reportTemplateMap = new HashMap();

	@PostConstruct
	private void init() throws Exception {
		List<ReportTemplate> reportTemplateList = reportService.findAllReportTemplates();
		reportTemplateList.forEach((template) -> {
			reportTemplateMap.put(template.getReportType(), template);
		});
	}

	/**
	 * This method is used to execute specific report as per dashboard
	 * 
	 * @param reportDetails
	 * @return
	 * @throws Exception
	 */
	@Override
	public ReportExecutedResponse excuteOneReport(ReportTemplate reportTemplate) throws Exception {
		ReportExecutedResponse exectuedRespone = null;
		if (!StringUtils.isEmpty(reportTemplate.getReportTemplateKey().getDashboardId())
				&& !StringUtils.isEmpty(reportTemplate.getReportTemplateKey().getReportId())) {

			// calculate Interval
			dateUtils.changeLiveReportInterval(reportTemplate.getReportType());

			String evaluateInterval = dateUtils.queryDate.get(reportTemplate.getReportType());
			reportTemplate.setExecutionInterval(evaluateInterval);
			// Fetch from druid
			List<Map<String, Object>> respone = druidRestClient.executeTemplateRequest(reportTemplate);
			exectuedRespone = druidRestClient.convertResponse(respone);
			// }

		}
		return exectuedRespone;
	}

	@Scheduled(fixedRateString = "${ngr.live.interval.miliseconds}")
	public void executeLiveReport() throws Exception {
		
			ReportTemplate template = reportTemplateMap.get("LIVE");
			this.template.convertAndSend("/livereport", excuteOneReport(template));
		
		

	}

	@Scheduled(fixedRateString = "${ngr.live.interval.hour.miliseconds}")
	public void executeLiveReportForHourly() throws Exception {
		ReportTemplate hourlyTemplate = reportTemplateMap.get("HOURLY");
		final ReportExecutedResponse hourlyReponse = excuteOneReport(hourlyTemplate);
		if (null != hourlyReponse) {
			this.template.convertAndSend("/livereport/HOURLY", hourlyReponse);
		}

	}

	/*@Scheduled(fixedRateString = "${ngr.live.interval.daily.miliseconds}")
	public void executeLiveReportForDaily() throws Exception {
		ReportTemplate dailyTemplate = reportTemplateMap.get("DAILY");
		final ReportExecutedResponse dailyReponse = excuteOneReport(dailyTemplate);
		if (null != dailyTemplate) {
			this.template.convertAndSend("/livereport/DAILY", dailyReponse);
		}

	}*/

/*	@Scheduled(fixedRateString = "${ngr.live.interval.month.miliseconds}")
	public void executeLiveReportForMonthly() throws Exception {

		ReportTemplate dailyTemplate = reportTemplateMap.get("MONTHLY");
		final ReportExecutedResponse dailyReponse = excuteOneReport(dailyTemplate);
		if (null != dailyTemplate) {
			this.template.convertAndSend("/livereport/MONTHLY", dailyReponse);
		}

	}*/

}
