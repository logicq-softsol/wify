package com.qh.ngr.service.report;

import com.qh.ngr.model.report.ReportTemplate;
import com.qh.ngr.response.ReportExecutedResponse;

public interface ReportExecutorService {


	ReportExecutedResponse   excuteOneReport(ReportTemplate reportTemplate) throws Exception;
	
	


}
