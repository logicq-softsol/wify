package com.qh.ngr.service.report;

import java.util.List;

import com.qh.ngr.model.report.ReportTemplate;

public interface ReportService {

	ReportTemplate findReportTemplate(String dashboardId, String reportId);

	List<ReportTemplate> findAllReportTemplates();

}
