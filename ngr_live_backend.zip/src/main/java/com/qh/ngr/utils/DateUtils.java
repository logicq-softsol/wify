package com.qh.ngr.utils;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.qh.ngr.model.report.ReportTemplate;
import com.qh.ngr.repository.ReportRepository;
import com.qh.ngr.response.ReportExecutedResponse;

@Component
public class DateUtils {

	@Autowired
	private Environment env;

	public static final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
	public Map<String, String> queryDate = new HashMap<>();



	public void changeLiveReportInterval(String reportType) throws Exception {
		String miliseconds = env.getProperty("ngr.live.interval.miliseconds");
		String delayHour = env.getProperty("ngr.live.interval.delay.hour");
		long seconds = TimeUnit.MILLISECONDS.toSeconds(Long.valueOf(miliseconds));

		LocalDateTime currentDateTime = LocalDateTime.now(ZoneId.systemDefault()).minusHours(Long.valueOf(delayHour));

		if ("INIT".equalsIgnoreCase(reportType)) {
			String initseconds = env.getProperty("ngr.live.interval.firsttime.seconds");
			Date intervalDate = Date
					.from(currentDateTime.minusMinutes(Long.valueOf(initseconds)).atZone(ZoneId.systemDefault()).toInstant());
			Date endDate = Date.from(currentDateTime.atZone(ZoneId.systemDefault()).toInstant());
			String date = simpleDateFormat.format(intervalDate) + "/" + simpleDateFormat.format(endDate);
			queryDate.put(reportType, date);
		}
		
		if ("LIVE".equalsIgnoreCase(reportType)) {
			Date intervalDate = Date
					.from(currentDateTime.minusSeconds(seconds).atZone(ZoneId.systemDefault()).toInstant());
			Date endDate = Date.from(currentDateTime.atZone(ZoneId.systemDefault()).toInstant());
			String date = simpleDateFormat.format(intervalDate) + "/" + simpleDateFormat.format(endDate);
			queryDate.put(reportType, date);
		}
		if ("CURRENT_DAY".equalsIgnoreCase(reportType)) {
			Date startDate = Date
					.from(currentDateTime.toLocalDate().atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
			Date endDate = Date.from(currentDateTime.minusSeconds(1).atZone(ZoneId.systemDefault()).toInstant());
			String date = simpleDateFormat.format(startDate) + "/" + simpleDateFormat.format(endDate);
			queryDate.put(reportType, date);
		}
		if ("CURRENT_HOUR".equalsIgnoreCase(reportType)) {
			LocalDateTime endLocaTime = currentDateTime.toLocalDate().atStartOfDay().plusHours(currentDateTime.getHour());
			Date endDate = Date.from(currentDateTime.minusSeconds(1).atZone(ZoneId.systemDefault()).toInstant());
			Date startDate = Date.from(endLocaTime.atZone(ZoneId.systemDefault()).toInstant());
			String date = simpleDateFormat.format(startDate) + "/" + simpleDateFormat.format(endDate);
			queryDate.put(reportType, date);
		}
		if ("HOURLY".equalsIgnoreCase(reportType)) {
			LocalDateTime endLocaTime = currentDateTime.toLocalDate().atStartOfDay()
					.plusHours(currentDateTime.getHour());
			Date endDate = Date.from(endLocaTime.atZone(ZoneId.systemDefault()).toInstant());
			Date startDate = Date.from(endLocaTime.minusHours(1).atZone(ZoneId.systemDefault()).toInstant());
			String date = simpleDateFormat.format(startDate) + "/" + simpleDateFormat.format(endDate);
			queryDate.put(reportType, date);
		}
		if ("DAILY".equalsIgnoreCase(reportType)) {
			LocalDateTime endLocaTime = currentDateTime.toLocalDate().atStartOfDay();
			Date endDate = Date.from(endLocaTime.atZone(ZoneId.systemDefault()).toInstant());
			Date startDate = Date.from(endLocaTime.minusDays(1).atZone(ZoneId.systemDefault()).toInstant());
			String date = simpleDateFormat.format(startDate) + "/" + simpleDateFormat.format(endDate);
			queryDate.put(reportType, date);

		}
		if ("MONTHLY".equalsIgnoreCase(reportType)) {
			Date monthEndDate = Date.from(currentDateTime.toLocalDate().withDayOfMonth(1).atStartOfDay()
					.atZone(ZoneId.systemDefault()).toInstant());
			Date monthBeginDate = Date.from(currentDateTime.toLocalDate().minusMonths(1).atStartOfDay()
					.atZone(ZoneId.systemDefault()).toInstant());
			String date = simpleDateFormat.format(monthBeginDate) + "/" + simpleDateFormat.format(monthEndDate);
			queryDate.put(reportType, date);
		}

	}

}
