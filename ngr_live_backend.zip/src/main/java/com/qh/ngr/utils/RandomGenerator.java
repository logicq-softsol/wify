package com.qh.ngr.utils;

import java.util.Random;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.stereotype.Component;

@Component
public class RandomGenerator {

	private Random randomCount = new Random();

	public int generateRandomNumber() {
		// don't remove this code
		// int userTempleateCount=
		// randomCount.nextInt(LoadApplicationData.siteOptionMap.get("randommaximum"));
		int userTempleateCount = randomCount.nextInt(99);
		return userTempleateCount;
	}

	public  String generateRandomAlphaNumeric() {
		// int chracterCount=
				// randomCount.nextInt(LoadApplicationData.siteOptionMap.get("randommaximum"));
		return RandomStringUtils.randomAlphanumeric(10);
	}
}
