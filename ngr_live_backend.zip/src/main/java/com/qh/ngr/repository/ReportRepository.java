package com.qh.ngr.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qh.ngr.model.report.ReportTemplate;
import com.qh.ngr.model.report.ReportTemplateKey;

public interface ReportRepository extends JpaRepository<ReportTemplate, ReportTemplateKey> {
	
	List<ReportTemplate> findByReportTemplateKeyDashboardId(String dashboardId);

	List<ReportTemplate> findByReportTemplateKeyReportId(String reportId);
	
}
