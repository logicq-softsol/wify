package com.qh.ngr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuickHealNgrApplication {
	// extends SpringBootServletInitializer
	public static void main(String[] args) {
		SpringApplication.run(QuickHealNgrApplication.class, args);
	}

}
