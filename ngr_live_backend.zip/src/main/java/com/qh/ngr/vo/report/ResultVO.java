package com.qh.ngr.vo.report;

import java.util.List;

public class ResultVO {
	
	private String timeStamp;
	
	private long time;;
	
	private List<CountDetailsVO>  countResult;

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public List<CountDetailsVO> getCountResult() {
		return countResult;
	}

	public void setCountResult(List<CountDetailsVO> countResult) {
		this.countResult = countResult;
	}

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return "ResultVO [timeStamp=" + timeStamp + ", time=" + time + ", countResult=" + countResult + "]";
	}

	
	

}
