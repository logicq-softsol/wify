package com.qh.ngr.vo.report;

import java.io.Serializable;
import java.util.Map;

public class ReportDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8874871734097197271L;
	
	private String dashId;
	private String reportId;
	private String reportName;
	
	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	private Map<String, Object> templateJson;

	public String getDashId() {
		return dashId;
	}

	public void setDashId(String dashId) {
		this.dashId = dashId;
	}

	public String getReportId() {
		return reportId;
	}

	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	public Map<String, Object> getTemplateJson() {
		return templateJson;
	}

	public void setTemplateJson(Map<String, Object> templateJson) {
		this.templateJson = templateJson;
	}

}
