package com.qh.ngr.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qh.ngr.client.druid.DruidRestClient;
import com.qh.ngr.model.report.ReportTemplate;
import com.qh.ngr.response.ReportExecutedResponse;
import com.qh.ngr.service.report.ReportExecutorService;
import com.qh.ngr.service.report.ReportExecutorServiceImpl;
import com.qh.ngr.service.report.ReportService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ReportController {

	@Autowired
	ReportExecutorService reportExecutorService;

	@Autowired
	DruidRestClient druidRestClient;

	@Autowired
	ReportService reportService;

	@RequestMapping(value = "/executedInitReport", method = RequestMethod.GET)
	public ResponseEntity<ReportExecutedResponse> executeInitReport() throws Exception {
		ReportExecutedResponse respone = reportExecutorService
				.excuteOneReport(reportService.findReportTemplate("fb7I12clAz", "1nlO3wlnlv"));
		return ResponseEntity.ok(respone);
	}

	@RequestMapping(value = "/executedInitReport/HOURLY", method = RequestMethod.GET)
	public ResponseEntity<ReportExecutedResponse> executeInitReportHourly() throws Exception {
		ReportExecutedResponse respone = reportExecutorService
				.excuteOneReport(reportService.findReportTemplate("fb7I12clAz", "1nlO3wlnlz"));
		return ResponseEntity.ok(respone);
	}

	@RequestMapping(value = "/executedInitReport/DAILY", method = RequestMethod.GET)
	public ResponseEntity<ReportExecutedResponse> executeInitReportDaily() throws Exception {
		ReportExecutedResponse respone = reportExecutorService
				.excuteOneReport(reportService.findReportTemplate("fb7I12clAz", "1nlO3wlnlY"));
		return ResponseEntity.ok(respone);
	}

	@RequestMapping(value = "/executedInitReport/MONTHLY", method = RequestMethod.GET)
	public ResponseEntity<ReportExecutedResponse> executeInitReportMonthly() throws Exception {
		ReportExecutedResponse respone = reportExecutorService
				.excuteOneReport(reportService.findReportTemplate("fb7I12clAz", "1nlO3wlnlw"));
		return ResponseEntity.ok(respone);
	}

	@RequestMapping(value = "/executedInitReport/CURRENT_DAY", method = RequestMethod.GET)
	public ResponseEntity<ReportExecutedResponse> executeInitReportCurrentDAY() throws Exception {
		ReportExecutedResponse respone = reportExecutorService
				.excuteOneReport(reportService.findReportTemplate("fb7I12clAz", "1nlO3wlnlu"));
		return ResponseEntity.ok(respone);
	}

	@RequestMapping(value = "/executedInitReport/CURRENT_HOUR", method = RequestMethod.GET)
	public ResponseEntity<ReportExecutedResponse> executeInitReportCurrentHOUR() throws Exception {
		ReportExecutedResponse respone = reportExecutorService
				.excuteOneReport(reportService.findReportTemplate("fb7I12clAz", "1nlO3wlnlt"));
		return ResponseEntity.ok(respone);
	}

	@RequestMapping(value = "/executedReport/{dashboardId}/{reportId}", method = RequestMethod.GET)
	public ResponseEntity<ReportExecutedResponse> executeInitReportForSpecifcDashboard(@PathVariable String dashboardId,
			String reportId) throws Exception {
		ReportExecutedResponse respone = reportExecutorService
				.excuteOneReport(reportService.findReportTemplate(dashboardId, reportId));
		return ResponseEntity.ok(respone);
	}
}
