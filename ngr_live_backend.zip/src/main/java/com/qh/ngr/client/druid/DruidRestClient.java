package com.qh.ngr.client.druid;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.qh.ngr.model.report.ReportTemplate;
import com.qh.ngr.response.ReportExecutedResponse;
import com.qh.ngr.utils.DateUtils;
import com.qh.ngr.vo.report.CountDetailsVO;
import com.qh.ngr.vo.report.ResultVO;

@Component
public class DruidRestClient {

	private static final Logger logger = Logger.getLogger(DruidRestClient.class);

	@Autowired
	private Environment env;

	@Autowired
	private DateUtils dateUtils;

	private ObjectMapper mapper = new ObjectMapper();

	private List<String> moduleList = new ArrayList<>();

	@PostConstruct
	private void init() {
		// Currently hardcode module later need to read from db
		moduleList.add("BASE_SCANNER");
		moduleList.add("MEMORY_SCANNER");
		moduleList.add("VIRUS_PROTECTION");
		moduleList.add("MAIL_PROTECTION");
		moduleList.add("PROPERTY_SHEET_SCANNER");
		moduleList.add("QUARANTINE_SCANNER");
		moduleList.add("OTHER_SCANNER");
	}

	/**
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	public List<?> postRequest(String request) throws Exception {
		RestTemplate restTemplate = new RestTemplate();

		// Header Prepation
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(request, headers);
		//System.out.println("Druid Query : " + request);
		String druidURL = env.getProperty("druid.broker.url");
		return restTemplate.postForObject(druidURL, entity, List.class);
	}

	/**
	 * 
	 * @param reportTemplate
	 * @return
	 * @throws Exception
	 */
	public List<Map<String, Object>> executeTemplateRequest(ReportTemplate reportTemplate) throws Exception {
		Map<Object, Object> tempateMap = mapper.readValue(reportTemplate.getTemplateJson(), Map.class);
		String interval = dateUtils.queryDate.get(reportTemplate.getReportType());
		tempateMap.put("intervals", interval);
		String tempatejson = mapper.writeValueAsString(tempateMap);
		List<Map<String, Object>> respone = (List<Map<String, Object>>) postRequest(tempatejson);
		return respone;
	}

	/**
	 * 
	 * @param respone
	 * @param response
	 */
	public ReportExecutedResponse convertResponse(List<Map<String, Object>> respone) {
		ReportExecutedResponse response = new ReportExecutedResponse();
		List<ResultVO> results = new ArrayList<>();
		Map<String, Map<String, Long>> dataCount = new HashMap<>();
		respone.forEach(res -> {
			String key = String.valueOf(res.get("timestamp"));
			if (!dataCount.containsKey(key)) {
				dataCount.put(key, new HashMap<>());
			}
			Map<String, Object> event = (Map<String, Object>) res.get("event");

			Long hitCount = Long.valueOf(String.valueOf(event.get("COUNT")));
			String moduleName = String.valueOf(event.get("module_id_str"));
			dataCount.get(key).put(moduleName, hitCount);
			moduleList.forEach((modl) -> {
				if (modl.equals(moduleName)) {
					dataCount.get(key).put(modl, hitCount);
				} else {
					dataCount.get(key).putIfAbsent(modl, 0l);
				}

			});

		});

		dataCount.keySet().forEach(da -> {
			try {
				ResultVO result = new ResultVO();
				result.setCountResult(new ArrayList<>());
				result.setTimeStamp(da);
				long cuurentTime = DateUtils.simpleDateFormat.parse(da).getTime();
				result.setTime(cuurentTime);
				Map<String, Long> resultCount = dataCount.get(da);
				resultCount.entrySet().forEach(count -> {
					CountDetailsVO recodCount = new CountDetailsVO();
					recodCount.setCount(count.getValue());
					recodCount.setName(count.getKey());
					result.getCountResult().add(recodCount);
				});
				results.add(result);
			} catch (Exception ex) {
				logger.error("Unable to process : " + ex.getMessage(), ex);
			}
		});

		response.setResults(results);
		return response;
	}

}